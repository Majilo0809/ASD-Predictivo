# Gramatica

gramatica = {
    "S": [["A", "uno", "B", "C"], ["S", "dos"]],
    "A": [["B", "C", "D"], ["A", "tres"], ["ε"]],
    "B": [["D", "cuatro", "C", "tres"], ["ε"]],
    "C": [["cinco", "D", "B"], ["ε"]],
    "D": [["seis"], ["ε"]]
}

# Primeros
def calcularPrimeros(gramatica):
    primeros = {nt: set() for nt in gramatica}

    cambio = True
    while cambio:
        cambio = False

        for A in gramatica:
            for produccion in gramatica[A]:

                for simbolo in produccion:
                    if simbolo not in gramatica:
                        if simbolo not in primeros[A]:
                            primeros[A].add(simbolo)
                            cambio = True
                        break
                    else:
                        if simbolo == A:
                            continue

                        antes = len(primeros[A])
                        primeros[A].update(primeros[simbolo] - {"ε"})

                        if "ε" not in primeros[simbolo]:
                            if len(primeros[A]) > antes:
                                cambio = True
                            break
                else:
                    if "ε" not in primeros[A]:
                        primeros[A].add("ε")
                        cambio = True

    return primeros


# Siguientes
def calcularSiguientes(gramatica, primeros, inicio):
    siguientes = {nt: set() for nt in gramatica}
    siguientes[inicio].add("$")

    cambio = True

    while cambio:
        cambio = False

        for A in gramatica:
            for produccion in gramatica[A]:

                for i in range(len(produccion)):
                    B = produccion[i]

                    if B in gramatica:
                        beta = produccion[i+1:]

			# First beta
                        first_beta = set()
                        contiene_epsilon = True

                        for simbolo in beta:
                            if simbolo in gramatica:
                                first_beta.update(primeros[simbolo] - {"ε"})
                                if "ε" not in primeros[simbolo]:
                                    contiene_epsilon = False
                                    break
                            else:
                                first_beta.add(simbolo)
                                contiene_epsilon = False
                                break

                        if contiene_epsilon:
                            first_beta.add("ε")

                        antes = len(siguientes[B])

                        # agregar First - ε
                        siguientes[B].update(first_beta - {"ε"})

                        # si beta => ε
                        if "ε" in first_beta:
                            siguientes[B].update(siguientes[A])

                        if len(siguientes[B]) > antes:
                            cambio = True

    return siguientes


primeros = calcularPrimeros(gramatica)
siguientes = calcularSiguientes(gramatica, primeros, "S")

print("----- Primeros ----- ")
for nt in primeros:
    print(nt, ":", primeros[nt])

print("\n----- Siguientes -----")
for nt in siguientes:
    print(nt, ":", siguientes[nt])
